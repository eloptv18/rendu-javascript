let combattant1 = { //définir mon personnage 
  name: "Java",
  vie: 100,
  attaque: 15,
  precision: 0.6
}

let combattant2 = { //définir mon ennemi
  name: "Blob",
  vie: 150,
  attaque: 27,
  precision: 0.2
}

function verifPrecision(precision) { //vérificatino de la précision de l'attaque
  return Math.random() < precision //pour le hasard
}

// fonction d'attaque précision puis attaque 
function attaquer(combattant1, combattant2) {
  if (verifPrecision(combattant1.precision)) {
    combattant2.vie -= combattant1.attaque
    console.log(
      combattant1.name + " touche " + combattant2.name +
      " et lui enlève " + combattant1.attaque + " points de vie.")
  } else {
    console.log(combattant1.name + " rate son attaque.")
  }
}

// boucle de combat qui fait que ça s'arrête qu'à un KO
while (combattant1.vie > 0 && combattant2.vie > 0) {
  console.log("Nouveau Round !")

  attaquer(combattant1, combattant2)
  console.log("Vie de " + combattant2.name + " : " + combattant2.vie)

  if (combattant2.vie <= 0) {
    console.log(combattant1.name + " a gagné !")
    break  // pour stopper la boucle
  }

  attaquer(combattant2, combattant1)
  console.log("Vie de " + combattant1.name + " : " + combattant1.vie)

  if (combattant1.vie <= 0) {
    console.log(combattant2.name + " a gagné !")
    break
  }
}
